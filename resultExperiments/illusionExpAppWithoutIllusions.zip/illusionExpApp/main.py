import numpy as np
import os
from bokeh.layouts import widgetbox, column, row, layout, Spacer
from bokeh.models.widgets import Button, RadioButtonGroup, Select, Slider, TextInput, RadioGroup, Toggle, Div, Paragraph, AutocompleteInput, TextAreaInput, Select
from bokeh.plotting import figure, curdoc
from bokeh.models import ColumnDataSource, Range1d
from bokeh.models.callbacks import CustomJS
from bokeh.models.sources import ColumnDataSource
import uuid
import json
import importlib

## filename of illusions (loacated in illusion subfolder)
illusionsFn = ["adelsons", "cafe_wall_illusion", "ebbinghausIllusion", "galileoIllusion", "HeringIllusionMain", "InducedGratingIllusion", "irradiationIllusion", "mullers_layer", "orbisonIllusion", "perfectSquare", "poppleIllusion","SimultaneousBrightnessContrast","tiltedTable2", "whiteIllusion","wundtIllusion"]

## flags
randIllusionOrder = True #randomize illusion order
randVariationOrder = True #randomize variation order
randInitDistortion = True #randomize slider range and init
enableChecks = True #enable user input checks
enableIllusionSelector = True #enable illusion selector drop down on welcome test for testing

## init experiment data structure
expData = []



## static resource folder
staticRsrcFolder = os.path.join("illusionExpApp","static")
if not os.path.exists(staticRsrcFolder):
    os.makedirs(staticRsrcFolder) 

## data output folder
expResultsFolder = os.path.join('illusionExpApp','results','experiment')
if not os.path.exists(expResultsFolder):
    os.makedirs(expResultsFolder)
questResultsFolder = os.path.join('illusionExpApp','results','questionnaire')
if not os.path.exists(questResultsFolder):
    os.makedirs(questResultsFolder) 

## import illusions
illusions = [importlib.import_module('illusions.'+ Fn) for Fn in illusionsFn]

for illusionId, illusion in enumerate(illusions):
    illusionRsrcFolder = os.path.join(staticRsrcFolder, illusionsFn[illusionId])
    if not os.path.exists(illusionRsrcFolder):
        os.makedirs(illusionRsrcFolder)

    illusion.init(illusionRsrcFolder)

numVariations = [illusion.getNumVariations() for illusion in illusions]

## generate participant ID
userID = str(uuid.uuid4())

###########################################
## welcome screen                        ##
###########################################
welcomeDiv = Div(text="""
<h1>Optical Illusion Experiment</h1>
<p>Welcome to the Optical Illusion Experiment. Before the experiment starts, you will fill out a questionnaire and read some general instructions.</p>

<b>Before you continue, ensure that your monitor is set to the sRGB color profile, brightness is set to 80%, and 
the ECO mode is turned off.</b>
<br><br>
<img style="border:thin solid black; width: 650px; height: auto;" src="https://docs.google.com/drawings/d/e/2PACX-1vQxZ3YEWowljVItN8cKFnfrd7jxxIwSstk_tYnFKQd71Rj3zG6wS-foouQbx4xsgXx4LzJqNbduHIY2/pub?w=907&amp;h=175">

""", width=700)

continue_button = Button( label='Continue', width=140, button_type = "default")


illusion_selector = Select(options=[""]+illusionsFn)

def illusion_selector_cb(attr, old, new):
    if new == "":
        return

    global illusionsPermMap, variationPermMap, enableChecks
    global illusionOrder, variationOrder, illusionID, variationID

    enableChecks = False
    illusionsPermMap = list(range(len(illusions)))

    variationPermMap = [list(range(illusion.getNumVariations())) for illusion in illusions]

    illusionOrder = illusionsFn.index(new)
    variationOrder = 0
    illusionID = int(illusionsPermMap[illusionOrder])
    variationID = int(variationPermMap[illusionOrder][variationOrder])

    #init_next_illusion()
    start_experiment()

illusion_selector.on_change('value', illusion_selector_cb)

password_input = TextInput(value="", width=250, title="Password:")
password_warning = Div(text="", width=300)

welcome_layout = column(welcomeDiv, row(password_input, column(Paragraph(),password_warning)), continue_button)

if enableIllusionSelector:
    welcome_layout.children.append(illusion_selector)

###########################################
## questionnaire screen                  ##
###########################################
questionnaireDiv = Div(text="""
<h1>Questionnaire</h1>
Please fill out the following form:
""", width=1000)

gender_rbg = RadioButtonGroup(
        labels=["male", "female"], active=None, width=150)
gender_help_text = Div(text="", width=300)


age_input = TextInput(value="", width=250, title="Age:")
age_help_text = Div(text="", width=300)


goto_instructions_button = Button( label='Continue', width=140, button_type = "default")

visImp_text = Paragraph(text="Do you have any visual impairments?", width=250)
visImp_rbg = RadioButtonGroup(
        labels=["Yes", "No"], active=None, width=150)
visImp_help_text = Div(text="", width=300)

visImpList_input = TextAreaInput(value="", width=500, title="If yes, what and when did you experience these problems?", height=100, cols=60)
visImpList_help_text = Div(text="", width=300)

everExp_text = Paragraph(text="Did you ever participate in an experiment related to perceptual illusions?", width=500)
everExp_rbg = RadioButtonGroup(
        labels=["Yes", "No"], active=None, width=150)
everExp_help_text = Div(text="", width=300)


questionnaire_layout = column(questionnaireDiv,
    Paragraph(text="Gender:", width=100),
    row(gender_rbg, gender_help_text), 
    row(age_input, column(Paragraph(),age_help_text)),
    visImp_text,
    row(visImp_rbg, visImp_help_text),
    row(visImpList_input, column(Paragraph(),visImpList_help_text)),
    everExp_text,
    row(everExp_rbg, everExp_help_text),
    goto_instructions_button)

def isPosInt(x):
    try:
        val = int(x)
        if(val > 0):
            return True
        else:
            return False
    except ValueError:
        return False

def saveQuestData():
    if not enableChecks:
        return True

    if gender_rbg.active == None:
        gender_help_text.text = "<p style=\"color:red\">&nbsp &lt-- please choose</p>"
        return False
    else:
        gender_help_text.text = ""

    if age_input.value == "":
        age_help_text.text = "<p style=\"color:red\">&nbsp &lt-- please fill out</p>"
        return False
    elif not isPosInt(age_input.value):
        age_help_text.text = "<p style=\"color:red\">&nbsp &lt-- invalid input, must be a postive integer</p>"
        return False
    else:
        age_help_text.text = ""

    if visImp_rbg.active == None:
        visImp_help_text.text = "<p style=\"color:red\">&nbsp &lt-- please choose</p>"
        return False
    else:
        visImp_help_text.text = ""

    if visImp_rbg.labels[visImp_rbg.active] == 'Yes' and visImpList_input.value == "":
        visImpList_help_text.text = "<p style=\"color:red\">&nbsp &lt-- please fill out</p>"
        return False
    else:
        visImpList_help_text.text = ""

    if everExp_rbg.active == None:
        everExp_help_text.text = "<p style=\"color:red\">&nbsp &lt-- please choose</p>"
        return False
    else:
        everExp_help_text.text = ""
    
    questData = {
        'Gender': gender_rbg.labels[gender_rbg.active],
        'Age': int(age_input.value),
        visImp_text.text: visImp_rbg.labels[visImp_rbg.active],
        visImpList_input.title: visImpList_input.value,
        everExp_text.text: everExp_rbg.labels[everExp_rbg.active],
    }

    with open('{}{}{}.json'.format(questResultsFolder,os.sep, userID), 'w') as outfile:
            json.dump(questData, outfile)

    return True

def start_questionnaire():

    if password_input.value != "pizza":
        password_warning.text = "<p style=\"color:red\">&nbsp &lt-- wrong</p>"
        return

    curdoc().clear()
    #curdoc().remove_root(welcome_layout)
    curdoc().add_root(questionnaire_layout)

continue_button.on_click(start_questionnaire)

###########################################
## instructions screen                   ##
###########################################
instDiv = Div(text="""
<h1>Instructions</h1>
<p>You will be presented with different variations of 15 optical illusions in form of an image. In each variation you can control a graphical feature with a distortion slider. For each variation you will see a screen like this:</p>

<img style="border:thin solid black; width: auto; height: 422px;"  src="https://docs.google.com/drawings/d/e/2PACX-1vSlOULtMbkrpY_JshvNQHj3tAwkTIs0Hliyz7R2Ztc_GX879oOYtzUcQG_AGrnVqiBfMek9LMecDeqI/pub?w=580&h=422">

<p>Follow the following steps for each variation:</p>
<ol>
    <li>Read the variation specific instruction.</li>
    <li>Change the slider value with the mouse or the arrow keys, while looking at the image on the right side of the screen.</li>
    <li>Answer the question. Select 1 for 'No' and 5 for 'Yes'. If you are unsure, select one of the values inbetween (2-4).</li>
    <li>Click on the button to continue to the next variation or illusion.</li>
</ol>

<p><b>Do not close or reload the browser window during the experiment, otherwise the experiment data will be lost.</b></p>
""", width=600)

start_exp_button = Button( label='Start Experiment', width=140, button_type = "default")

instructions_layout = layout(column(instDiv, start_exp_button))

def goto_instructions_button_cb():
    if not saveQuestData():
        return

    curdoc().clear()
    curdoc().add_root(instructions_layout)

goto_instructions_button.on_click(goto_instructions_button_cb)

###########################################
## experiment screen                     ##
###########################################

## generate illusion and variation order
if randIllusionOrder:
    illusionsPermMap = np.random.permutation(len(illusions)) #map from illusionOrder to illusionID
else:
    illusionsPermMap = list(range(len(illusions)))
if randVariationOrder:
    variationPermMap = [np.random.permutation(illusion.getNumVariations()) for illusion in illusions] #map from variationOrder to variationID
else:
    variationPermMap = [list(range(illusion.getNumVariations())) for illusion in illusions]

## set up first illusion
illusionOrder = 0 
variationOrder = 0
illusionID = int(illusionsPermMap[illusionOrder])
variationID = int(variationPermMap[illusionID][variationOrder])

## Create various gui widgets
titleDiv = Div(text="", width=1000)

distortion_slider = Slider(start=0, end=1, step=0.001, value=0.5, show_value=False, tooltips=False, width=300)

sliderStart = 0
sliderEnd = 1
sliderInit = 0.5

def reset_slider(): 
    # randomize slider min, max and starting value for every illusion switch 
    # (to avoid the subject remembering the values from previously completed illusion variations)
    global sliderStart, sliderEnd, sliderInit, distortion_slider
    if randInitDistortion:
        sliderStart = np.random.uniform(0, 0.2)
        sliderEnd = np.random.uniform(0.8, 1)
        sliderInit = np.random.uniform(distortion_slider.start, distortion_slider.end)
    else:
        sliderStart = 0    
        sliderEnd = 1
        sliderInit = 0.5

    distortion_slider.start = sliderStart   
    distortion_slider.end = sliderEnd
    distortion_slider.value = sliderInit


radio_group = RadioGroup( labels=['1', '2', '3', '4', '5  (Yes)'], active=None, inline=True, width=220)

warning_text = Div(text="", width=200)

next_button = Button( label='Next', width=140, button_type = "default")

instructionDiv = Div(text="", width=400, height=100)
questionPar = Div(text="", width=300)

pBox = row(figure(width=500, height=500))

## init illusion
def init_next_illusion():
    global pBox, titleDiv, instructionDiv, questionPar, old_val

    reset_slider()

    titleDiv.text = "<h2>[{}/{}]: {} - Variation {} of {}</h2>".format(illusionOrder+1, len(illusions), illusions[illusionID].getName(), variationOrder+1, illusions[illusionID].getNumVariations())

    
    p = illusions[illusionID].draw(variationID, distortion_slider.value)
    pBox.children[0] = p

    try:
        instructionDiv.text = illusions[illusionID].getInstructions(variationID)
        questionPar.text = "<b>{}</b>".format(illusions[illusionID].getQuestion(variationID))
    except TypeError:
        instructionDiv.text = illusions[illusionID].getInstructions()
        questionPar.text="<b>{}</b>".format(illusions[illusionID].getQuestion())

    old_val = distortion_slider.value


exp_layout = column(titleDiv, row(column(
    Div(text="<b>Instruction:</b>", width=100),
    row(Spacer(width=20), instructionDiv),
    Div(text="<b>Distort:</b>", width=100),
    row(Spacer(width=20), distortion_slider),
    questionPar,
    row(Spacer(width=20), Paragraph(text="(No)", width=35), radio_group, warning_text),
    next_button, width=500), pBox))

## callbacks
do_periodic_update = True
old_val = 0 #last slider value

# illusions are updated in periodic callback instead of slider callback to throttle drawing commands to max 5/s
def periodic_cb():
    global old_val, pBox

    if do_periodic_update and distortion_slider.value != old_val: #only update when slider value changed
        _illusionID = illusionID
        _variationID = variationID
        if _variationID >= numVariations[_illusionID] or _variationID < 0: #check for invalid state
            print("periodic_cb issue: illusionID: {}, variationID: {}".format(_illusionID, _variationID))
            return

        old_val = distortion_slider.value
        curdoc().hold()
        p = illusions[_illusionID].draw(_variationID, distortion_slider.value)
        pBox.children[0] = p
        curdoc().unhold() #for performance reasens ,gather all document changes in draw to one update

def start_experiment():
    init_next_illusion()
    curdoc().clear()
    curdoc().add_root(exp_layout)
    curdoc().add_periodic_callback(periodic_cb, 200)

start_exp_button.on_click(start_experiment)

def next_button_cb():
    global variationOrder, illusionOrder, variationID, illusionID, pBox, do_periodic_update

    try:
        if enableChecks:
            if radio_group.active == None:
                warning_text.text = "<p style=\"color:red\">&nbsp &lt-- please choose</p>"
                return
            else:
                warning_text.text = ""
        else:
            radio_group.active = 2

        do_periodic_update = False #pause periodic callback

        expData.append({'illusionName': illusions[illusionID].getName(), 'illusionID': illusionID, 'illusionOrder': illusionOrder, 'variationID': variationID, 'variationOrder': variationOrder, 'distortion': distortion_slider.value, 'inverted': radio_group.active+1, 'sliderStart': sliderStart, 'sliderEnd': sliderEnd, 'sliderInit': sliderInit})

        variationOrder = variationOrder+1
        if variationOrder < illusions[illusionID].getNumVariations():
            variationID = int(variationPermMap[illusionID][variationOrder])
        else:
            #new illusion: save data to disk
            try:
                with open('{}{}{}.json'.format(expResultsFolder,os.sep, userID), 'w') as outfile:
                    json.dump(expData, outfile)
            except:
                print("file write error")
            

            illusionOrder = illusionOrder+1
            if illusionOrder < len(illusions):
                variationOrder = 0
                illusionID = int(illusionsPermMap[illusionOrder])
                variationID = int(variationPermMap[illusionID][variationOrder])
            else:
                # end of experiment
                curdoc().clear()

                curdoc().add_root(column(Div(text="""
                <h1>Finished!</h1>
                <p>Thanks for participating!
                <br>
                Please fill out the final questionnaire. <br><br>
                Your Subject ID is: <b>{}</b>
                </p>
                """.format(userID[0:8]), width=600), width=600))
                return
    except:
        print("catched error in next_button_cb: {}, {}, {}, {}".format(illusionOrder, variationOrder, illusionID, variationID))

        #check if variables are in invalid state
        if variationID >= numVariations[illusionID] or variationID < 0:
            print("next_button_cb invalid variable state: illusionID: {}, variationID: {}, illusionOrder: {}, variationOrder: {}".format(illusionID, variationID, illusionOrder, variationOrder))

            # reset variables to valid state
            illusionID = int(illusionsPermMap[illusionOrder])
            variationOrder = 0
            variationID = int(variationPermMap[illusionID][variationOrder])

    
    radio_group.active = None




    try:
        init_next_illusion()
    except:
        print("next_button_cb issue: init_next_illusion error")

    

    do_periodic_update = True


next_button.on_click(next_button_cb)


## set doc
curdoc().title = "Optical Illusion Experiment"
curdoc().add_root(welcome_layout)

